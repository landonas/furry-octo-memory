import React from "react";
import './NewItem.css';
import { Link } from "react-router-dom";


const NewItem = props => {

    return(
        <Link to="/Add"> asdf </Link>
    );

}


export default NewItem;