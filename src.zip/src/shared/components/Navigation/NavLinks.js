import React from "react";
import { NavLink } from "react-router-dom";
import './NavLinks.css'


/*  
            <li className="nav-links">
            <NavLink to="/Add">Add</NavLink>
            <NavLink to="/test">Test</NavLink>
            <NavLink to="/Add">third</NavLink>
        </li>


*/
const NavLinks = props => {
    return (
        <li className="nav-links">

        </li>
        
        
    )
}



export default NavLinks;