import React from "react";
import './Table.css'


const Table = (props) =>{

    return(
        <>
        <h1>Items</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>AGE</th>
                    <th>MESSAGE</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tr>
                <th>1239jg</th>
                <th>45</th>
                <th>How does this look?</th>
                <th>Laptop</th>
            </tr>
            <tr>
                <th>1239jg</th>
                <th>45</th>
                <th>How does this look?</th>
                <th>Laptop</th>
            </tr>
            <tr>
                <th>1239jg</th>
                <th>45</th>
                <th>How does this look?</th>
                <th>Laptop</th>
            </tr>
            <tr>
                <th>1239jg</th>
                <th>45</th>
                <th>How does this look?</th>
                <th>Laptop</th>
            </tr>
        </table>
        </>
    );

}

export default Table;