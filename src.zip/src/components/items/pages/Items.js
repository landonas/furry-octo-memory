import React from "react";


const Items = () => {


    return(
        <h1>Hello from items</h1>
    )
}



export default Items;